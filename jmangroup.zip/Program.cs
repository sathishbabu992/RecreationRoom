﻿using System;
using System.Collections;

namespace JMANGROUP
{
    class Program
    {
        static void Main(string[] args)
        {
            int count = 0;       
            String gender = "",temp="";
            while (count <= 4)
            {
                Console.WriteLine("Please Specify your gender in Words:");
                gender = Console.ReadLine();
                if (count == 0)
                {
                    count++;
                    temp = gender.ToUpper();
                }
                else if (temp == gender.ToUpper())
                {
                    count++;
                    if (count <= 3)
                    {
                        Console.WriteLine(count + " " + temp + " genders in room");
                    }
                }
                else
                {  
                   Console.WriteLine(count +" "+temp+" genders in room "+gender.ToUpper()+" are not allowed");               
                }
                if (count>=3)
                {
                    Console.WriteLine("Room capacity is only for 3 members, next member not allowed");
                    break;     
                }
                
            }
            Console.WriteLine("Program Exited.... Thank You...");
        }
    }
}
